---
name: Feature request
about: Suggest a new idea for flutter-icons.
title: ''
labels: ''
assignees: ''

---

<!-- Thank you for using flutter-icons!

    If you have some new ideas on flutter-icons, 
    please submit an issue according to the following steps. We will reply to you immediately 
-->


## Use case

<!--
     Please tell us the problem you are running into that led to you wanting
     a new feature.

     Is your feature request related to a problem? Please give a clear and
     concise description of what the problem is.
-->
```
```

## Proposal

<!--
     Briefly but precisely describe what you would like Flutter to be able to do.
     Consider attaching images showing what you are imagining.

-->
```
```
