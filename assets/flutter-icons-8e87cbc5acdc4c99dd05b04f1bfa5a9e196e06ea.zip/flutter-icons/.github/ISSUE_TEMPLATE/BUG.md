---
name: bug.
about: Some bugs about flutter-icons.
title: ''
labels: ''
assignees: ''

---

<!-- Thank you for using flutter-icons!

    If you find a bug from using flutter-icons, 
    you can submit an issue according to the following requirements and we will deal with it in time

-->


 ## Env info
 <!--  Run `flutter doctor` fill in the operating environment information -->
 ```
 ```



 ## Bug info
 <!-- Describe any bug information you find  -->
 ```
 ```