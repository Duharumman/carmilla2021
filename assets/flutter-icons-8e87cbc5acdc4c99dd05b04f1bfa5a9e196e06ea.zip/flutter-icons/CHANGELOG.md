## 1.1.1-nullsafety.0

- Migrated package and sample to Null Safety
- Bumped up package version

## 1.1.0

- The FlutterIcons class is provided to access all Icons

## 1.0.0+1

- Enforce code robustness

## 1.0.0

- Refactored API

## 0.3.1

- File movement and adding assertions

## 0.3.0

- WeatherIcons added

## 0.2.5

- IconToggle added

## 0.2.0

- FontAwesome5_Free added

## 0.1.5

- Update MaterialCommunityIcons to version 4.0.96

## 0.1.4

- Add hasIconData method

## 0.1.3

- Foundation added

## 0.1.0

- This library contains several icon libraries, including the well-known ant-design icon library, material icon library, and so on
